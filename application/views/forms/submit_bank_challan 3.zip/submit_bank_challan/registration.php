  <div class="content-wrapper">
    <?php $this->load->view('forms/form_header');   ?>

    <!-- Main content -->
    <section class="content" style="padding-top: 0px !important;">
      <?php $this->load->view('forms/navigation_bar');   ?>
      <div class="box box-primary box-solid">
        <div class="box-body">

          <div class="row">
            <div class="col-md-7">
              <div class="col-md-6">
                <div style="border:1px solid #9FC8E8; border-radius: 10px; min-height: 100px;  margin: 5px; padding: 5px; background-color: white;">
                  <h4>
                    <i class="fa fa-info-circle" aria-hidden="true"></i> How system calculate <i>"Deposit Fee Challan" ?</i>
                  </h4>
                  <ol>
                    <li>According to the data you have entered, your institute was established in <strong><?php echo date('M Y', strtotime($school->yearOfEstiblishment)); ?></strong>.
                      For session <strong><?php echo $session_detail->sessionYearTitle; ?></strong> your institute
                      charged Max Tuition Fee
                      <strong><?php echo $max_tuition_fee; ?> Rs. </strong> per month.
                    </li>
                    <li>As per PSRA Registration and Renewal Fee Structure, Institute charging monthly fee between
                      <strong><?php echo $fee_sturucture->fee_min; ?> Rs. </strong> and <strong> <?php echo $fee_sturucture->fee_max; ?> Rs. </strong>
                      Must Deposit
                      <ol>
                        <li> Application Processing Fee: <strong><?php echo $fee_sturucture->renewal_app_processsing_fee; ?> Rs. </strong></li>
                        <li> Inspection Fee: <strong><?php echo $fee_sturucture->renewal_app_inspection_fee; ?> Rs.</strong></li>
                        <li> Security Fee (1st Time Registration)
                          <ol>
                            <?php
                            $query = "SELECT * FROM `levelofinstitute`
                              WHERE school_type_id = '" . $school->school_type_id . "'
                              ";
                            $level_securities = $this->db->query($query)->result();
                            foreach ($level_securities as $level_security) {
                            ?>
                              <li><?php echo  $level_security->levelofInstituteTitle; ?> <strong> <?php echo  $level_security->security_fee; ?> Rs.</strong> </li>
                            <?php } ?>
                          </ol>
                        </li>

                    </li>

                  </ol>
                  <li>In case of confusion and queries, please contact <strong>PSRA MIS Section <a style="font-weight: bold; color:red" href="tel:+92091-9216205">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                        091-9216205 </a></strong></li>
                  </li>
                  </ol>
                  <button onclick="renewal_fee_sturucture()" class="btn btn-link">
                    <i class="fa fa-info-circle" aria-hidden="true"></i> PSRA Registration Fee Struture Detail</button>
                </div>
              </div>

              <div class="col-md-6" style=" min-height:450px; ">
                <div style="border:1px solid #9FC8E8; border-radius: 10px; min-height: 437px !important;  margin: 5px; padding: 5px; background-color: white;">
                  <h4>Session: <?php echo $session_detail->sessionYearTitle; ?> Due Dates</h4>
                  <table class="table table-bordered">

                    <tr>
                      <th>S.No.</th>
                      <th>Last Date</th>
                      <th>Fines</th>
                    </tr>
                    <?php
                    $count = 1;
                    foreach ($session_fee_submission_dates as $session_fee_submission_date) { ?>
                      <tr>
                        <td><?php echo $count++; ?></td>
                        <td>Upto <?php echo date('d M, Y', strtotime($session_fee_submission_date->last_date)); ?></td>
                        <td>
                          <?php
                          if ($session_fee_submission_date->fine_percentage != 'fine') { ?>
                            <?php echo $session_fee_submission_date->fine_percentage; ?> %
                          <?php } else { ?>
                            <?php echo $session_fee_submission_date->detail; ?>
                          <?php } ?>
                        </td>
                      </tr>
                    <?php }
                    ?>
                    <?php
                    $pecial_fine = 0;
                    if ($session_id == 1) { ?>
                      <tr>
                        <td colspan="2" style="text-align: center;"> Settle Areas 2018-19 Special Fine<br />1 Dec, 2019</td>
                        <td>
                          <strong>50,000 Rs.</strong> <br> Primary / Middle Level <br>
                          <strong>200,000 Rs. </strong> <br> High / Higher Level
                        </td>
                      </tr>
                      <tr>
                        <td colspan="2" style="text-align: center;"> FATA 2018-19 Special Fine<br />01 Jan, 2020</td>
                        <td>
                          <strong>50,000 Rs.</strong> <br> Primary / Middle Level <br>
                          <strong>200,000 Rs. </strong> <br> High / Higher Level
                        </td>
                      </tr>



                    <?php
                      if ($school->level_of_school_id == 1  or  $school->level_of_school_id == 2) {
                        $special_fine = 50000;
                      }
                      if ($school->level_of_school_id == 3  or  $school->level_of_school_id == 4) {
                        $special_fine = 200000;
                      }
                    } ?>

                  </table>

                </div>
              </div>
              <?php $this->load->view('forms/submit_bank_challan/online_apply_instructions');   ?>
            </div>

            <div class="col-md-5">
              <div style="border:1px solid #9FC8E8; border-radius: 10px; min-height: 100px;  margin: 5px; padding: 5px; background-color: white;">
                <h4>Session: <?php echo $session_detail->sessionYearTitle; ?> Registration Fee Detail</h4>
                <table class="table" style="font-size: 13px;">
                  <thead>
                    <tr>
                      <th>Fee Category</th>
                      <th>Amount (Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Application Processing Fee</td>
                      <td>Rs. <?php echo number_format($fee_sturucture->renewal_app_processsing_fee); ?></td>
                    </tr>
                    <tr>
                      <td>Inspection Fee</td>
                      <td>Rs. <?php echo number_format($fee_sturucture->renewal_app_inspection_fee); ?></td>
                    </tr>
                    <tr>
                      <td><strong> Session <?php echo $session_detail->sessionYearTitle; ?> Registration Fee </strong></td>
                      <td>
                        <strong>
                          <?php $total = $fee_sturucture->renewal_app_processsing_fee + $fee_sturucture->renewal_app_inspection_fee;

                          echo number_format($total);
                          ?> Rs.
                        </strong>
                      </td>

                    </tr>

                    <tr>
                      <td colspan="2">
                        <style>
                          .table_reg>tbody>tr>td,
                          .table_reg>tbody>tr>th,
                          .table_reg>tfoot>tr>td,
                          .table_reg>tfoot>tr>th,
                          .table_reg>thead>tr>td,
                          .table_reg>thead>tr>th {
                            padding: 3px;
                            line-height: 1.42857143;
                            vertical-align: top;
                            border-top: 1px solid #ddd;
                            text-align: center;
                          }
                        </style>
                        <table class="table table_reg">
                          <tr>
                            <th> Due's Date </th>
                            <th> Late Fee % </th>
                            <th> Late Fee </th>
                            <th> Session <?php echo $session_detail->sessionYearTitle; ?> Registration Fee </th>
                            <th>Total</th>
                          </tr>
                          <?php
                          $count = 1;

                          foreach ($session_fee_submission_dates as $session_fee_submission_date) { ?>

                            <tr>
                              <th>
                                Upto <?php echo date('d M, Y', strtotime($session_fee_submission_date->last_date)); ?>
                              </th>
                              <?php if ($session_fee_submission_date->fine_percentage == 0) { ?>
                                <td colspan="2"> <strong> Normal Fee </strong></td>
                              <?php } else { ?>
                                <td>

                                  <?php echo $session_fee_submission_date->fine_percentage; ?> %</td>
                                <td>
                                  <?php
                                  $fine = 0;
                                  $fine = ($session_fee_submission_date->fine_percentage * $total) / 100;
                                  echo number_format($fine);
                                  ?>

                                </td>
                              <?php } ?>
                              <td>
                                <?php echo number_format($fine + $total);  ?>
                              </td>

                              <td>
                                <strong>


                                  <?php echo number_format($fine + $total + $security); ?>

                                </strong>
                              </td>

                            </tr>



                          <?php } ?>

                        </table>
                      </td>

                    </tr>


                    <tr>
                      <td colspan="2" style="text-align:center;">
                        <a target="new" class="btn btn-primary" href="<?php echo site_url("form/print_registration_bank_challan/$school_id") ?>"> <i class="fa fa-print" aria-hidden="true"></i> Print PSRA Deposit Slip / Bank Challan</a>
                        <div style="border:1px solid #9FC8E8; border-radius: 10px; color:red; min-height: 100px;  margin: 5px; padding: 5px;">

                          <p>
                            As soon as the PSRA official examines the case or processes it, he or she will inform you of the security and fines associated with it.
                          </p>
                          <p>
                            جیسے ہی اہلکار کیس کی جانچ کرے گا یا اس پر کارروائی کرے گا، وہ آپ کو اس سے منسلک سیکیورٹی اور جرمانے کے بارے میں مطلع کرے گا۔
                          </p>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>

              </div>
              <?php $this->load->view('forms/online_apply');   ?>


            </div>



          </div>


          <div style="font-size: 16px; text-align: center; border:1px solid #9FC8E8; border-radius: 10px; min-height: 10px;  margin: 10px; padding: 10px; background-color: white;">

            <div class="row">
              <div class="col-md-6">
                <a class="btn btn-success" style="margin: 2px;" href="<?php echo site_url("form/section_h/$school_id"); ?>">
                  <i class="fa fa-arrow-left" aria-hidden="true" style="margin-right: 10px;"></i> Previous Section ( Fee Concession ) </a>

              </div>

              <div class="col-md-6">
                <?php if ($finished == 1) { ?>
                  <a href="<?php echo site_url('form/submit_application_online/' . $school_id . '/' . $schools_id) ?>" onclick="return confirm('Are you sure. you want to submit?')" class=" btn btn-danger">
                    <i class="fa fa-flag-checkered" aria-hidden="true"></i>
                    Submit Application Online</a>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>


      </div>
    </section>

  </div>